﻿var map, csv;

require([
  "esri/map",
  "esri/layers/CSVLayer",
  "esri/Color",
  "esri/symbols/SimpleMarkerSymbol",
  "esri/renderers/SimpleRenderer",
  "esri/InfoTemplate",
  "esri/urlUtils",
  "dojo/domReady!"
], function (
  Map, CSVLayer, Color, SimpleMarkerSymbol, SimpleRenderer, InfoTemplate, urlUtils
) {    
    map = new Map("mapDiv", {
        basemap: "gray",
        center: [-87.629, 41.878],
        zoom: 12
    });

    csv = new CSVLayer("data/crimedata.csv", {        
    });

    var orangeRed = new Color([238, 69, 0, 0.5]); // hex is #ff4500
    var marker = new SimpleMarkerSymbol("solid", 15, null, orangeRed);

    var renderer = new SimpleRenderer(marker);
    csv.setRenderer(renderer);
    
    var template = new InfoTemplate("Crime Detail", "<b>ID:</b> ${ID}</br><b>Case Number:</b> ${Case Number}</br><b>Date:</b> ${Date}</br><b>Block:</b> ${Block}</br><b>Primary Type:</b> ${Primary Type}</br><b>Description:</b> ${Description}</br><b>Location Description:</b> ${Location Description}</br><b>Arrest:</b> ${Arrest}</br><b>Domestic:</b> ${Domestic}</br><b>Ward:</b> ${Ward}</br><b>Community Area:</b> ${Community Area}</br><b>FBI Code:</b> ${FBI Code}</br><b>Year:</b> ${Year}</br><b>Updated On:</b> ${Updated On}");
    csv.setInfoTemplate(template);
    map.addLayer(csv);
});